"use client";

import { useState } from "react";

type Props = {
  projectId: string;
  initial: { subject: string; body: string; status: string } | null;
};

const STATUS_NEXT: Record<string, { label: string; to: string } | null> = {
  DRAFT: { label: "Mark reviewed", to: "REVIEWED" },
  REVIEWED: { label: "Mark sent", to: "SENT" },
  SENT: null,
  ARCHIVED: null,
};

export default function ColdEmailCard({ projectId, initial }: Props) {
  const [status, setStatus] = useState(initial?.status ?? "DRAFT");
  const [copied, setCopied] = useState(false);
  const [saving, setSaving] = useState(false);

  if (!initial) {
    return (
      <p className="text-[13px] text-slate">
        No draft yet. Emails are drafted for leads recommended Pursue or Watch during ingestion.
      </p>
    );
  }

  const copy = async () => {
    await navigator.clipboard.writeText(`Subject: ${initial.subject}\n\n${initial.body}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const advance = async () => {
    const next = STATUS_NEXT[status];
    if (!next) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/leads/${projectId}/email`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: next.to }),
      });
      if (res.ok) setStatus(next.to);
    } finally {
      setSaving(false);
    }
  };

  const next = STATUS_NEXT[status];
  const statusColor =
    status === "SENT" ? "#127E58" : status === "REVIEWED" ? "#0E7C7B" : "#B45309";

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <span className="num text-[11px] font-600 tracking-wide" style={{ color: statusColor }}>
          {status}
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={copy}
            className="rounded-md border border-mist bg-panel px-2.5 py-1 text-[12px] font-500 text-slate transition-colors hover:border-mute hover:text-ink"
          >
            {copied ? "Copied" : "Copy"}
          </button>
          {next && (
            <button
              onClick={advance}
              disabled={saving}
              className="rounded-md bg-accent px-2.5 py-1 text-[12px] font-500 text-white transition-colors hover:bg-accent-ink disabled:opacity-50"
            >
              {saving ? "Saving…" : next.label}
            </button>
          )}
        </div>
      </div>

      <div className="rounded-md border border-line bg-paper">
        <div className="border-b border-line px-3 py-2">
          <span className="eyebrow">Subject</span>
          <div className="mt-0.5 text-[13.5px] font-600 text-ink">{initial.subject}</div>
        </div>
        <pre className="whitespace-pre-wrap px-3 py-3 font-sans text-[13px] leading-relaxed text-ink">
{initial.body}
        </pre>
      </div>
      <p className="mt-2 text-[11px] text-mute">
        Add your unsubscribe footer before sending. Nothing is dispatched from here.
      </p>
    </div>
  );
}
