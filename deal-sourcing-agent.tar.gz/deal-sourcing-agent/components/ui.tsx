import Link from "next/link";

export type FitTier = "strong" | "watch" | "cold";

export function tierFor(score: number | null | undefined): FitTier {
  if (score == null) return "cold";
  if (score >= 75) return "strong";
  if (score >= 55) return "watch";
  return "cold";
}

const TIER_COLOR: Record<FitTier, string> = {
  strong: "#127E58",
  watch: "#B45309",
  cold: "#8A94A1",
};

// --- Signature element ------------------------------------------------------
// A vertical "energization rail": a thin bar whose fill height and colour
// encode the lead's fit. Borrowed from the voltage indicators on electrical
// switchgear — the more energised the lead, the higher and greener the rail.
export function EnergizationRail({ score }: { score: number | null | undefined }) {
  const tier = tierFor(score);
  const pct = Math.max(6, Math.min(100, score ?? 0));
  return (
    <div className="relative h-9 w-[3px] overflow-hidden rounded-full bg-mist" title={`Fit ${score ?? "—"}`}>
      <div
        className="absolute bottom-0 left-0 w-full rounded-full"
        style={{ height: `${pct}%`, background: TIER_COLOR[tier] }}
      />
    </div>
  );
}

export function FitMeter({ score, label }: { score: number | null | undefined; label?: string }) {
  const tier = tierFor(score);
  const pct = Math.max(0, Math.min(100, score ?? 0));
  return (
    <div className="w-full">
      {label && <div className="eyebrow mb-1">{label}</div>}
      <div className="flex items-center gap-2">
        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-mist">
          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: TIER_COLOR[tier] }} />
        </div>
        <span className="num w-7 text-right text-[12px] text-slate">{score ?? "—"}</span>
      </div>
    </div>
  );
}

const REC_STYLE: Record<string, string> = {
  PURSUE: "bg-strong/10 text-strong",
  WATCH: "bg-watch/10 text-watch",
  PASS: "bg-mist text-mute",
};

export function RecBadge({ rec }: { rec: string | null | undefined }) {
  if (!rec) return null;
  return (
    <span className={`num rounded px-1.5 py-0.5 text-[10.5px] font-600 tracking-wide ${REC_STYLE[rec] ?? REC_STYLE.PASS}`}>
      {rec}
    </span>
  );
}

const TECH_LABEL: Record<string, string> = {
  SOLAR: "Solar",
  WIND: "Wind",
  BATTERY: "Battery",
  HYBRID: "Solar+Storage",
  PUMPED_HYDRO: "Pumped Hydro",
  OTHER: "Other",
};

export function TechChip({ tech }: { tech: string }) {
  return (
    <span className="rounded border border-mist bg-paper px-2 py-0.5 text-[11.5px] font-500 text-slate">
      {TECH_LABEL[tech] ?? tech}
    </span>
  );
}

const STATUS_LABEL: Record<string, string> = {
  ENQUIRY: "Enquiry",
  PROPOSED: "Proposed",
  COMMITTED: "Committed",
  OPERATING: "Operating",
  WITHDRAWN: "Withdrawn",
  UNKNOWN: "Unknown",
};

export function StatusChip({ status }: { status: string }) {
  const dim = status === "OPERATING" || status === "WITHDRAWN";
  return (
    <span className={`num text-[11px] tracking-wide ${dim ? "text-mute" : "text-slate"}`}>
      {STATUS_LABEL[status] ?? status}
    </span>
  );
}

export function SourcePill({ source }: { source: string }) {
  return (
    <span className="num rounded-sm bg-paper px-1.5 py-0.5 text-[10px] tracking-wide text-mute">
      {source}
    </span>
  );
}

// --- formatters -------------------------------------------------------------
export function fmtMw(mw: number | null | undefined): string {
  return mw == null ? "—" : `${mw.toLocaleString()} MW`;
}

export function fmtCapex(aud: bigint | number | null | undefined): string {
  if (aud == null) return "—";
  const n = typeof aud === "bigint" ? Number(aud) : aud;
  if (n >= 1e9) return `A$${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `A$${(n / 1e6).toFixed(0)}M`;
  return `A$${n.toLocaleString()}`;
}

export function Panel({ title, children, right }: { title?: string; children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-mist bg-panel shadow-panel">
      {title && (
        <header className="flex items-center justify-between border-b border-line px-4 py-2.5">
          <h2 className="eyebrow">{title}</h2>
          {right}
        </header>
      )}
      <div className="px-4 py-3.5">{children}</div>
    </section>
  );
}

export function ExternalLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="text-accent underline-offset-2 hover:underline">
      {children}
    </a>
  );
}

export { Link };
