/**
 * Seed — populates the database with realistic (illustrative, not real) Australian
 * renewable projects so you can run the dashboard end-to-end with zero API keys
 * or live feeds. Includes proponents with multiple projects (so track record and
 * capitalNeedFit have something to chew on), scored leads, and drafted emails.
 *
 *   npm run seed
 *
 * Names/numbers here are invented for demonstration. Replace by running the real
 * pipeline once your AEMO_GENINFO_URL / feeds are configured.
 */

import { prisma } from "../lib/db";
import { normalizeName, fingerprint } from "../ingest/normalize";
import { linkedinSearchUrl } from "../ingest/abr";
import type { Technology, Stage, Region } from "@prisma/client";

interface SeedProject {
  name: string;
  tech: Technology;
  mw: number;
  region: Region;
  state: string;
  stage: Stage;
  lat?: number;
  lng?: number;
  source: "AEMO" | "EPBC";
}

interface SeedProponent {
  name: string;
  abn?: string;
  entityType?: string;
  website?: string;
  directors?: { name: string; role: string }[];
  projects: SeedProject[];
  // lead overrides for the *primary* (first) project
  lead?: {
    fitScore: number;
    stageFit: number;
    scaleFit: number;
    techFit: number;
    capitalNeedFit: number;
    rationale: string;
    flags: string[];
    subject: string;
    body: string;
  };
}

const DATA: SeedProponent[] = [
  {
    name: "Brightfield Renewables Pty Ltd",
    abn: "61 004 117 200",
    entityType: "Australian Private Company",
    website: "https://brightfield.example.com.au",
    directors: [
      { name: "Priya Nadkarni", role: "Director" },
      { name: "Tom Whitlock", role: "Director" },
    ],
    projects: [
      {
        name: "Mallee Plains Solar + Battery",
        tech: "SOLAR_BATTERY",
        mw: 220,
        region: "VIC1",
        state: "VIC",
        stage: "ENQUIRY",
        lat: -34.74,
        lng: 142.16,
        source: "AEMO",
      },
      {
        name: "Wimmera North Solar",
        tech: "SOLAR",
        mw: 95,
        region: "VIC1",
        state: "VIC",
        stage: "PROPOSED",
        source: "EPBC",
      },
    ],
    lead: {
      fitScore: 86,
      stageFit: 95,
      scaleFit: 80,
      techFit: 95,
      capitalNeedFit: 78,
      rationale:
        "Fresh connection enquiry for a 220MW solar+battery hybrid, squarely pre-FID and in our core technology. Mid-tier independent developer with one other proposed project but no operating fleet or visible fund behind it, so a predevelopment bridge is plausibly needed. Deciding factor: stage and clean technology fit.",
      flags: ["capacity from enquiry, unconfirmed"],
      subject: "your mallee plains connection enquiry",
      body: `Hi [First name],

I saw Brightfield's connection enquiry for the Mallee Plains solar and battery project. A 220MW hybrid in that part of the network is a serious bit of work to get through feasibility and interconnection.

I'm with Blockmate Infrastructure. We put predevelopment equity into projects exactly at this stage, the gap between site control and financial close, so sponsors can fund interconnection and feasibility without giving up the project early.

Not pitching anything. I'd just like to understand where Mallee Plains is and how you're thinking about funding the predevelopment phase. Worth a 20 minute call?

[Name]
[Title], Blockmate Infrastructure
[email]`,
    },
  },
  {
    name: "Coorong Energy Partners",
    abn: "29 118 552 010",
    entityType: "Australian Private Company",
    directors: [{ name: "Daniel Osei", role: "Managing Director" }],
    projects: [
      {
        name: "Coorong Battery Energy Storage",
        tech: "BATTERY",
        mw: 150,
        region: "SA1",
        state: "SA",
        stage: "PROPOSED",
        lat: -35.6,
        lng: 139.4,
        source: "AEMO",
      },
    ],
    lead: {
      fitScore: 79,
      stageFit: 82,
      scaleFit: 75,
      techFit: 90,
      capitalNeedFit: 70,
      rationale:
        "150MW standalone BESS in SA, proposed and pre-FID. Single-project sponsor with no operating assets, consistent with a first-time developer needing predevelopment capital. Slightly lower scale fit as a standalone battery, but strong technology and stage alignment.",
      flags: ["first-time sponsor"],
      subject: "coorong bess - predevelopment funding",
      body: `Hi [First name],

I came across the Coorong battery storage project in the public project pipeline. Standalone storage in South Australia is well placed given where the market is heading.

I work with Blockmate Infrastructure. We provide bridge equity for the predevelopment phase, interconnection, feasibility and permitting, before final investment decision, so sponsors aren't forced to bring in a partner too early on poor terms.

I'd like to learn where the project is and how you're approaching predevelopment funding. Could we find 20 minutes?

[Name]
[Title], Blockmate Infrastructure
[email]`,
    },
  },
  {
    name: "Pilbara Green Power Holdings",
    abn: "74 600 991 233",
    entityType: "Australian Public Company",
    website: "https://pilbaragp.example.com.au",
    directors: [
      { name: "Helen Marsh", role: "Chair" },
      { name: "Raj Patel", role: "CEO" },
    ],
    projects: [
      {
        name: "Pilbara Solar Hub Stage 2",
        tech: "SOLAR",
        mw: 400,
        region: "NSW1",
        state: "WA",
        stage: "COMMITTED",
        source: "AEMO",
      },
      {
        name: "Pilbara Solar Hub Stage 1",
        tech: "SOLAR",
        mw: 350,
        region: "NSW1",
        state: "WA",
        stage: "OPERATING",
        source: "AEMO",
      },
      {
        name: "Hedland Wind",
        tech: "WIND",
        mw: 180,
        region: "NSW1",
        state: "WA",
        stage: "OPERATING",
        source: "AEMO",
      },
    ],
    lead: {
      fitScore: 38,
      stageFit: 45,
      scaleFit: 60,
      techFit: 85,
      capitalNeedFit: 20,
      rationale:
        "Large, well-capitalized public company with an operating fleet (two operating assets, 530MW) and a committed Stage 2 that has likely reached FID. Strong technology fit but low capital-need fit: this proponent does not need a predevelopment bridge and our entry point has passed. Deciding factor: already capitalized.",
      flags: ["major developer", "already capitalized", "FID likely passed"],
      subject: "",
      body: "",
    },
  },
  {
    name: "Snowy Valleys Pumped Hydro Pty Ltd",
    entityType: "Australian Private Company",
    directors: [{ name: "Marco Bianchi", role: "Director" }],
    projects: [
      {
        name: "Snowy Valleys Pumped Hydro",
        tech: "PUMPED_HYDRO",
        mw: 600,
        region: "NSW1",
        state: "NSW",
        stage: "PROPOSED",
        lat: -35.3,
        lng: 148.2,
        source: "EPBC",
      },
    ],
    lead: {
      fitScore: 68,
      stageFit: 80,
      scaleFit: 55,
      techFit: 80,
      capitalNeedFit: 62,
      rationale:
        "600MW pumped hydro at proposal stage, picked up via an EPBC referral with location data. Pumped hydro is long-dated and capital intensive, so scale fit is moderate, the predevelopment cheque is a small slice of a very large capex. Single-project entity suggests genuine capital need. Worth a conversation.",
      flags: ["long development timeline", "large total capex"],
      subject: "snowy valleys pumped hydro",
      body: `Hi [First name],

I noticed the Snowy Valleys pumped hydro project come through the EPBC referrals. Long-duration storage of that scale is exactly what the system is short of.

I'm with Blockmate Infrastructure. We fund the predevelopment phase for projects like this, the studies, approvals and early works that have to happen before a project is financeable, without taking the whole thing off your hands.

I'd value 20 minutes to understand the project and how you're resourcing the predevelopment work. Open to a call?

[Name]
[Title], Blockmate Infrastructure
[email]`,
    },
  },
  {
    name: "Riverina Solar Co",
    entityType: "Australian Private Company",
    directors: [{ name: "Sarah Quinn", role: "Director" }],
    projects: [
      {
        name: "Riverina East Solar Farm",
        tech: "SOLAR",
        mw: 130,
        region: "NSW1",
        state: "NSW",
        stage: "ENQUIRY",
        lat: -34.9,
        lng: 146.5,
        source: "AEMO",
      },
    ],
    lead: {
      fitScore: 74,
      stageFit: 92,
      scaleFit: 68,
      techFit: 95,
      capitalNeedFit: 58,
      rationale:
        "130MW solar at connection enquiry, earliest and best stage, core technology. Capital need is moderate-to-good: small independent with no other projects on record. Scale is on the lighter side but still economic for a predevelopment bridge. Strong, actionable lead.",
      flags: ["small independent developer"],
      subject: "riverina east connection enquiry",
      body: `Hi [First name],

I saw the connection enquiry for Riverina East. Getting a 130MW solar project from here through interconnection and feasibility is the hard yards, and it's usually where funding gets tight.

I work with Blockmate Infrastructure. We provide predevelopment equity for that exact stage so you can fund the path to financial close without bringing in an equity partner too early.

Not selling anything, just keen to understand where the project is and how you're funding the next phase. Worth a short call?

[Name]
[Title], Blockmate Infrastructure
[email]`,
    },
  },
];

async function main() {
  console.log("[seed] clearing existing data...");
  await prisma.lead.deleteMany();
  await prisma.projectSource.deleteMany();
  await prisma.project.deleteMany();
  await prisma.proponent.deleteMany();

  for (const sp of DATA) {
    const proponent = await prisma.proponent.create({
      data: {
        name: normalizeName(sp.name),
        rawNames: [sp.name],
        abn: sp.abn,
        entityType: sp.entityType,
        entityStatus: sp.abn ? "Active" : undefined,
        website: sp.website,
        linkedinUrl: linkedinSearchUrl(sp.name),
        directors: sp.directors ?? undefined,
      },
    });

    let primaryProjectId: string | null = null;

    for (const [i, pr] of sp.projects.entries()) {
      const project = await prisma.project.create({
        data: {
          fingerprint: fingerprint(pr.name, pr.region, pr.tech),
          name: pr.name,
          technology: pr.tech,
          capacityMw: pr.mw,
          region: pr.region,
          state: pr.state,
          stage: pr.stage,
          latitude: pr.lat,
          longitude: pr.lng,
          proponentId: proponent.id,
          sources: {
            create: {
              source: pr.source,
              sourceRef: pr.source === "EPBC" ? `EPBC-${1000 + i}` : null,
              sourceUrl:
                pr.source === "AEMO"
                  ? "https://www.aemo.com.au/energy-systems/electricity/national-electricity-market-nem/nem-forecasting-and-planning/forecasting-and-planning-data/generation-information"
                  : "https://epbcpublicportal.environment.gov.au",
              raw: { seeded: true, ...pr },
            },
          },
        },
      });
      if (i === 0) primaryProjectId = project.id;
    }

    if (sp.lead && primaryProjectId) {
      await prisma.lead.create({
        data: {
          projectId: primaryProjectId,
          fitScore: sp.lead.fitScore,
          stageFit: sp.lead.stageFit,
          scaleFit: sp.lead.scaleFit,
          techFit: sp.lead.techFit,
          capitalNeedFit: sp.lead.capitalNeedFit,
          rationale: sp.lead.rationale,
          flags: sp.lead.flags,
          emailSubject: sp.lead.subject || null,
          emailBody: sp.lead.body || null,
          emailStatus: "DRAFT",
        },
      });
    }
  }

  const leads = await prisma.lead.count();
  const projects = await prisma.project.count();
  const proponents = await prisma.proponent.count();
  console.log(`[seed] done: ${proponents} proponents, ${projects} projects, ${leads} leads`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
