/**
 * Track record — "previous deals done by the parties involved", derived for FREE.
 *
 * The insight that makes this work without a paid M&A database: a developer's
 * other projects already in our AEMO/EPBC data *are* their track record. Group
 * every project by proponent and you have a credible public development history:
 * what they've built, what's operating, what's in their pipeline, and how active
 * they are. This is also a direct input to the capitalNeedFit score — a proponent
 * with three operating assets is differently capitalized than a first-timer.
 *
 * A fuller financing history (rounds, M&A) lives in paid sources; that's the
 * optional news-search / PitchBook slot, not this.
 */

import { prisma } from "../lib/db";
import type { Project } from "@prisma/client";

export interface TrackRecord {
  totalProjects: number;
  operating: number;
  inPipeline: number;
  totalCapacityMw: number;
  byTechnology: Record<string, number>;
  projects: Project[];
}

export async function getTrackRecord(proponentId: string): Promise<TrackRecord> {
  const projects = await prisma.project.findMany({
    where: { proponentId },
    orderBy: { firstSeenAt: "desc" },
  });

  const byTechnology: Record<string, number> = {};
  let totalCapacityMw = 0;
  let operating = 0;
  let inPipeline = 0;

  for (const p of projects) {
    byTechnology[p.technology] = (byTechnology[p.technology] ?? 0) + 1;
    totalCapacityMw += p.capacityMw ?? 0;
    if (p.stage === "OPERATING") operating++;
    if (["ENQUIRY", "PROPOSED", "COMMITTED"].includes(p.stage)) inPipeline++;
  }

  return {
    totalProjects: projects.length,
    operating,
    inPipeline,
    totalCapacityMw,
    byTechnology,
    projects,
  };
}

/** Compact one-line summary for prompts and table cells. */
export function summarizeTrackRecord(tr: TrackRecord): string {
  const techs = Object.entries(tr.byTechnology)
    .map(([k, v]) => `${v}x ${k}`)
    .join(", ");
  return `${tr.totalProjects} project(s) on record (${tr.operating} operating, ${tr.inPipeline} in pipeline), ~${Math.round(tr.totalCapacityMw)} MW total. Tech mix: ${techs || "n/a"}.`;
}
