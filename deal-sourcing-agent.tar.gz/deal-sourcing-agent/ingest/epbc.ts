/**
 * EPBC referrals ingestion — the SECONDARY signal.
 *
 * Why it matters: large renewable/infra projects with a land footprint almost
 * always trigger a federal environmental referral under the EPBC Act. The
 * referral carries a richer proponent description and (sometimes) a project
 * location — things AEMO's electrical-only view lacks. A project appearing in
 * BOTH AEMO and EPBC, recently, is your highest-confidence lead.
 *
 * Source: the EPBC Act Public Portal — https://epbcpublicportal.environment.gov.au
 * Data is Commonwealth public data (CC BY 4.0).
 *
 * Two access notes learned during research:
 *  1. The data.gov.au "Referrals Spatial Database" (CKAN) is HISTORICAL ONLY —
 *     it stops at 2018. Useful for back-filling track record, useless for fresh
 *     leads. Do not rely on it for the live feed.
 *  2. The live portal is a single-page app. The robust path is its underlying
 *     JSON/OData endpoint (the portal fetches referral lists as JSON). The exact
 *     endpoint shifts; set EPBC_FEED_URL in .env once you've confirmed the current
 *     one from the portal's network tab. If unset, this module no-ops gracefully
 *     so the rest of the pipeline still runs on AEMO alone.
 *
 * The parser below is written against the common referral JSON shape
 * (title, proponent, referralNumber, status, lat/lng, dates). Adjust field names
 * to match whatever the live endpoint returns.
 */

import {
  NormalizedProject,
  classifyTechnology,
  classifyStage,
} from "./normalize";

// Keyword gate: we only keep energy/infra referrals, not every mine or marina.
const ENERGY_KEYWORDS =
  /solar|wind|battery|\bbess\b|storage|hydro|pumped|renewable|hydrogen|power station|generation|transmission|gigafactory/i;

interface RawReferral {
  title?: string;
  proponent?: string;
  referralNumber?: string;
  status?: string;
  state?: string;
  latitude?: number;
  longitude?: number;
  url?: string;
}

export async function ingestEpbc(): Promise<NormalizedProject[]> {
  const url = process.env.EPBC_FEED_URL;
  if (!url) {
    console.warn(
      "[epbc] EPBC_FEED_URL not set — skipping EPBC feed. " +
        "Pipeline continues on AEMO only. See ingest/epbc.ts header for how to find the endpoint.",
    );
    return [];
  }

  console.log(`[epbc] fetching ${url}`);
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (!res.ok) {
    console.error(`[epbc] fetch failed: ${res.status} — continuing without EPBC`);
    return [];
  }

  const data = (await res.json()) as { value?: RawReferral[]; results?: RawReferral[] } | RawReferral[];
  const list: RawReferral[] = Array.isArray(data)
    ? data
    : (data.value ?? data.results ?? []);

  const out: NormalizedProject[] = [];
  for (const r of list) {
    const title = (r.title ?? "").trim();
    if (!title) continue;
    if (!ENERGY_KEYWORDS.test(`${title} ${r.proponent ?? ""}`)) continue;

    out.push({
      name: title,
      proponentRaw: (r.proponent ?? "Unknown proponent").trim(),
      technology: classifyTechnology(title),
      capacityMw: null, // referrals rarely state MW; AEMO fills this in on merge
      region: null,
      state: r.state ?? null,
      stage: r.status ? classifyStage(r.status) : "PROPOSED",
      latitude: r.latitude ?? null,
      longitude: r.longitude ?? null,
      source: "EPBC",
      sourceRef: r.referralNumber ?? null,
      sourceUrl: r.url ?? "https://epbcpublicportal.environment.gov.au",
      raw: r,
    });
  }

  console.log(`[epbc] parsed ${out.length} energy/infra referrals`);
  return out;
}
