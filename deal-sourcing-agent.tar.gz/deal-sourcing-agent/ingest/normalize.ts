import { createHash } from "crypto";
import type { Technology, Stage, Region, Source } from "@prisma/client";

/**
 * The single shape every feed normalizes into before it touches the database.
 * AEMO and EPBC have wildly different schemas; both get mapped to this.
 */
export interface NormalizedProject {
  name: string;
  proponentRaw: string;
  technology: Technology;
  capacityMw: number | null;
  region: Region | null;
  state: string | null;
  stage: Stage;
  latitude: number | null;
  longitude: number | null;
  source: Source;
  sourceRef: string | null;
  sourceUrl: string | null;
  raw: unknown;
}

/** Normalize a company name so "ACME Energy Pty Ltd" and "Acme Energy" dedupe. */
export function normalizeName(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/\b(pty|ltd|limited|llc|inc|corporation|corp|holdings|group|australia|aust)\b/g, "")
    .replace(/[^a-z0-9 ]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/** Stable fingerprint so the same project from AEMO + EPBC collapses to one row. */
export function fingerprint(name: string, region: string | null, tech: string): string {
  const key = `${normalizeName(name)}|${(region ?? "").toLowerCase()}|${tech.toLowerCase()}`;
  return createHash("sha1").update(key).digest("hex");
}

/** Best-effort technology classification from free-text fuel/tech fields. */
export function classifyTechnology(text: string): Technology {
  const t = text.toLowerCase();
  const solar = /solar|photovolt|\bpv\b/.test(t);
  const battery = /batter|\bbess\b|storage/.test(t);
  if (solar && battery) return "SOLAR_BATTERY";
  if (battery) return "BATTERY";
  if (solar) return "SOLAR";
  if (/wind/.test(t)) return "WIND";
  if (/pumped|phes|hydro/.test(t)) return "PUMPED_HYDRO";
  if (/hydrogen/.test(t)) return "GREEN_HYDROGEN";
  if (/transmission|interconnect/.test(t)) return "TRANSMISSION";
  if (/hybrid/.test(t)) return "HYBRID";
  return "OTHER";
}

/** Map AEMO's status vocabulary to our lifecycle stages. */
export function classifyStage(text: string): Stage {
  const s = text.toLowerCase();
  if (/enquir/.test(s)) return "ENQUIRY";
  if (/withdraw|lapsed/.test(s)) return "WITHDRAWN";
  if (/operat|existing|commission|generating/.test(s)) return "OPERATING";
  if (/committed|advanced|construction/.test(s)) return "COMMITTED";
  if (/proposed|publicly announced|anticipat|application/.test(s)) return "PROPOSED";
  return "UNKNOWN";
}

const STATE_TO_REGION: Record<string, Region> = {
  nsw: "NSW1",
  act: "NSW1",
  qld: "QLD1",
  sa: "SA1",
  tas: "TAS1",
  vic: "VIC1",
};

export function regionFromState(state: string | null): Region | null {
  if (!state) return null;
  const key = state.toLowerCase().replace(/[^a-z]/g, "").slice(0, 3);
  return STATE_TO_REGION[key] ?? STATE_TO_REGION[key.slice(0, 2)] ?? null;
}
