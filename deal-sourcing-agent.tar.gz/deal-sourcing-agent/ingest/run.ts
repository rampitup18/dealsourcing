/**
 * Pipeline orchestrator — the cron entrypoint.
 *
 * Run daily (or weekly). Each stage is independent and logged, so a failure in
 * one feed doesn't sink the run. Order: ingest → persist → qualify → draft emails.
 *
 *   npm run pipeline
 *
 * Schedule it however your host does cron (Vercel Cron, a Render/Railway cron
 * job, GitHub Actions on a schedule, or system crontab). The whole thing is one
 * Node process; no long-running server needed for ingestion.
 */

import { ingestAemo } from "./aemo";
import { ingestEpbc } from "./epbc";
import { persist } from "./persist";
import { qualifyNewProjects } from "./qualify";
import { composeEmailsForLeads } from "./compose-email";
import { prisma } from "../lib/db";

async function main() {
  const startedAt = Date.now();
  console.log(`\n=== Deal pipeline run @ ${new Date().toISOString()} ===\n`);

  // 1. INGEST — feeds are independent; tolerate one failing.
  const records = [];
  try {
    records.push(...(await ingestAemo()));
  } catch (err) {
    console.error("[pipeline] AEMO ingest failed:", String(err));
  }
  try {
    records.push(...(await ingestEpbc()));
  } catch (err) {
    console.error("[pipeline] EPBC ingest failed:", String(err));
  }
  console.log(`[pipeline] ${records.length} normalized records collected\n`);

  // 2. PERSIST (dedupe + cross-source merge)
  const { created, merged } = await persist(records);
  console.log(`[pipeline] persisted: ${created} new, ${merged} merged\n`);

  // 3. QUALIFY (LLM scoring against the mandate)
  const newLeads = await qualifyNewProjects();
  console.log(`[pipeline] ${newLeads} new leads qualified\n`);

  // 4. DRAFT OUTREACH (LLM, drafts only — never auto-sends)
  const drafted = await composeEmailsForLeads();
  console.log(`[pipeline] ${drafted} cold emails drafted\n`);

  const secs = ((Date.now() - startedAt) / 1000).toFixed(1);
  console.log(`=== Done in ${secs}s ===\n`);
}

main()
  .catch((err) => {
    console.error("[pipeline] fatal:", err);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
