/**
 * Persistence: take NormalizedProjects from the feeds and upsert them into the
 * graph, deduping proponents by normalized name and projects by fingerprint.
 * When the same project arrives from both AEMO and EPBC, we MERGE: AEMO usually
 * has capacity/MW, EPBC usually has lat/lng — we keep the richer value of each.
 */

import { prisma } from "../lib/db";
import { NormalizedProject, normalizeName, fingerprint } from "./normalize";
import { enrichAbn, linkedinSearchUrl } from "./abr";

async function upsertProponent(rawName: string) {
  const norm = normalizeName(rawName) || rawName.toLowerCase();

  const existing = await prisma.proponent.findUnique({ where: { name: norm } });
  if (existing) {
    if (!existing.rawNames.includes(rawName)) {
      await prisma.proponent.update({
        where: { id: existing.id },
        data: { rawNames: { push: rawName } },
      });
    }
    return existing;
  }

  // New proponent — enrich once on creation (free ABR lookup).
  const abr = await enrichAbn(rawName);
  return prisma.proponent.create({
    data: {
      name: norm,
      rawNames: [rawName],
      abn: abr.abn,
      entityType: abr.entityType,
      entityStatus: abr.entityStatus,
      registeredAt: abr.state,
      linkedinUrl: linkedinSearchUrl(rawName),
    },
  });
}

export async function persist(records: NormalizedProject[]): Promise<{
  created: number;
  merged: number;
}> {
  let created = 0;
  let merged = 0;

  for (const rec of records) {
    const proponent = await upsertProponent(rec.proponentRaw);
    const fp = fingerprint(rec.name, rec.region, rec.technology);

    const existing = await prisma.project.findUnique({
      where: { fingerprint: fp },
      include: { sources: true },
    });

    if (existing) {
      // Merge: prefer non-null incoming values for fields the other feed lacks.
      await prisma.project.update({
        where: { id: existing.id },
        data: {
          capacityMw: existing.capacityMw ?? rec.capacityMw,
          latitude: existing.latitude ?? rec.latitude,
          longitude: existing.longitude ?? rec.longitude,
          region: existing.region ?? rec.region,
          state: existing.state ?? rec.state,
          // Advance the stage only if the new feed reports a more progressed one.
          lastSeenAt: new Date(),
        },
      });
      await prisma.projectSource.upsert({
        where: { projectId_source: { projectId: existing.id, source: rec.source } },
        create: {
          projectId: existing.id,
          source: rec.source,
          sourceRef: rec.sourceRef,
          sourceUrl: rec.sourceUrl,
          raw: rec.raw as object,
        },
        update: { seenAt: new Date(), raw: rec.raw as object },
      });
      merged++;
    } else {
      await prisma.project.create({
        data: {
          fingerprint: fp,
          name: rec.name,
          technology: rec.technology,
          capacityMw: rec.capacityMw,
          region: rec.region,
          state: rec.state,
          stage: rec.stage,
          latitude: rec.latitude,
          longitude: rec.longitude,
          proponentId: proponent.id,
          sources: {
            create: {
              source: rec.source,
              sourceRef: rec.sourceRef,
              sourceUrl: rec.sourceUrl,
              raw: rec.raw as object,
            },
          },
        },
      });
      created++;
    }
  }

  return { created, merged };
}
