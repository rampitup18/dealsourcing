// ===========================================================================
// COLD EMAIL DRAFTING.
//
// Drafts a short, credible first-contact email for a qualified lead, in the
// voice of the configured sender (set SENDER_* in .env). Output is always
// saved as a DRAFT and surfaced in the dashboard for a human to review and
// send — it is never dispatched automatically. Scott's value is a personal,
// credible first contact in a small market; the agent writes the draft, the
// human keeps the relationship.
//
// On compliance: B2B cold outreach is permitted under the Australian Spam Act
// 2003 provided the message identifies the sender accurately and offers a
// functional unsubscribe. The draft includes an honest sign-off; add your
// unsubscribe line/footer before sending at volume.
// ===========================================================================

import Anthropic from "@anthropic-ai/sdk";
import { MANDATE } from "../lib/mandate";
import type { RawLead } from "../lib/types";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

function emailModel(): string {
  return (
    process.env.ANTHROPIC_EMAIL_MODEL ||
    process.env.ANTHROPIC_MODEL ||
    "claude-sonnet-4-6"
  );
}

function sender() {
  return {
    name: process.env.SENDER_NAME || "Scott",
    title: process.env.SENDER_TITLE || "Infrastructure Partner, Blockmate Infrastructure",
    email: process.env.SENDER_EMAIL || "",
    phone: process.env.SENDER_PHONE || "",
  };
}

export type DraftedEmail = { subject: string; body: string };

const STYLE = `Write a cold outreach email from an infrastructure capital partner to the
developer of a renewable project. Constraints:
- Short: 110–160 words. Respectful of their time.
- Open with a specific, accurate reference to THEIR project (name, technology, scale, region) so it's clearly not a mass mailer.
- One sentence on who we are: ${MANDATE.fund}, providing pre-FID predevelopment and bridge capital (A$1–50M) to carry projects through interconnection, feasibility, permitting and long-lead equipment ahead of FID.
- The ask is soft and genuine: are they raising predevelopment capital, and would they be open to a short call to hear where the project is at. We are NOT asking them to sell or commit anything.
- Plain, warm, peer-to-peer tone. No hype, no superlatives, no buzzwords ("synergies", "leverage", "cutting-edge"). No em dashes.
- Do not invent facts about the project beyond what you are given. If a detail is unknown, don't reference it.
- End with a one-line sign-off using the sender details provided.

Return ONLY JSON (no markdown fences):
{ "subject": "...", "body": "..." }
The body should be plain text with line breaks, ready to paste into an email client.`;

export async function draftColdEmail(lead: RawLead): Promise<DraftedEmail> {
  const s = sender();
  const projectFacts = [
    `Project: ${lead.projectName}`,
    `Proponent: ${lead.proponentName}`,
    `Technology: ${lead.technology}`,
    lead.capacityMw != null ? `Capacity: ${lead.capacityMw} MW` : null,
    lead.region ? `Region: ${lead.region}` : null,
    `Status: ${lead.status}`,
  ]
    .filter(Boolean)
    .join("\n");

  const signature = [
    s.name,
    s.title,
    s.email,
    s.phone,
  ].filter(Boolean).join("\n");

  try {
    const msg = await anthropic.messages.create({
      model: emailModel(),
      max_tokens: 600,
      system: STYLE,
      messages: [
        {
          role: "user",
          content: `Draft the email.\n\nPROJECT:\n${projectFacts}\n\nSIGN OFF AS:\n${signature}`,
        },
      ],
    });

    const text = (msg.content as Array<{ type: string; text?: string }>)
      .filter((b) => b.type === "text")
      .map((b) => b.text ?? "")
      .join("")
      .replace(/```json|```/g, "")
      .trim();

    const parsed = JSON.parse(text) as Partial<DraftedEmail>;
    if (!parsed.subject || !parsed.body) throw new Error("incomplete draft");
    return { subject: String(parsed.subject), body: String(parsed.body) };
  } catch (err) {
    console.warn(`[email] model error for "${lead.projectName}" — using template:`, (err as Error).message);
    const scale = lead.capacityMw ? `${lead.capacityMw} MW ` : "";
    return {
      subject: `${lead.projectName} — predevelopment capital`,
      body: `Hi,\n\nI came across ${lead.projectName}, your ${scale}${lead.technology.toLowerCase()} project${lead.region ? ` in ${lead.region}` : ""}, and wanted to reach out.\n\nWe are ${MANDATE.fund}. We provide pre-FID predevelopment and bridge capital, typically A$1 to 50M, to carry projects through interconnection, feasibility, permitting and long-lead equipment ahead of a final investment decision.\n\nIf you are looking at predevelopment funding for this project, I would welcome a short call to hear where things are at. No agenda beyond understanding the project.\n\nWould you be open to that?\n\n${signature}`,
    };
  }
}
