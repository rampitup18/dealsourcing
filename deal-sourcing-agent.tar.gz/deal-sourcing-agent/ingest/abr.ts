/**
 * ABR (Australian Business Register) enrichment — FREE government data.
 *
 * Turns a proponent name into a legal entity: ABN, entity type, status, and
 * state of registration. This is the legitimate, free first layer of "who is
 * this party". Director names come from ASIC, which is paid/per-search — we
 * leave a slot for it but don't call it here.
 *
 * Setup: register for a free GUID at https://abr.business.gov.au/Tools/WebServices
 * and set ABR_GUID in .env. Without it, this no-ops and the proponent simply
 * shows name + a LinkedIn search link.
 *
 * We use the ABR JSON "MatchingNames" search endpoint.
 */

export interface AbrResult {
  abn?: string;
  entityType?: string;
  entityStatus?: string;
  state?: string;
}

export async function enrichAbn(name: string): Promise<AbrResult> {
  const guid = process.env.ABR_GUID;
  if (!guid) return {};

  const endpoint =
    "https://abr.business.gov.au/json/MatchingNames.aspx" +
    `?name=${encodeURIComponent(name)}&maxResults=1&guid=${guid}`;

  try {
    const res = await fetch(endpoint);
    if (!res.ok) return {};
    // ABR returns JSONP-style "callback({...})"; strip the wrapper.
    const text = (await res.text()).replace(/^[^(]*\(/, "").replace(/\)\s*;?\s*$/, "");
    const data = JSON.parse(text) as {
      Names?: Array<{ Abn?: string; State?: string; NameType?: string }>;
    };
    const first = data.Names?.[0];
    if (!first?.Abn) return {};
    return { abn: first.Abn, state: first.State, entityType: first.NameType };
  } catch (err) {
    console.warn(`[abr] enrichment failed for "${name}":`, String(err));
    return {};
  }
}

/** Until a contact API is wired, give the analyst a one-click research jump. */
export function linkedinSearchUrl(name: string): string {
  return `https://www.linkedin.com/search/results/companies/?keywords=${encodeURIComponent(name)}`;
}
