// ===========================================================================
// SEAM 3 — Proponent enrichment.
//
// Free today:
//   - ABR ABN Lookup turns a proponent name into a legal entity, ABN, status
//     and state. Register for a GUID (free) and set ABR_LOOKUP_GUID.
//
// The honest contacts stub:
//   - There is no free, clean API for "decision-maker's email at company X".
//     For v1 we store the entity, a LinkedIn company-search URL, and a website
//     guess. Director names come free only where you already have them.
//
// The paid slot (wire this in later):
//   - enrichContacts() is where an Apollo / Hunter / RocketReach call goes to
//     populate real Contact.email values. Left as a no-op stub on purpose.
// ===========================================================================

import { makeMatchKey } from "../lib/mandate";

export type EntityEnrichment = {
  abn: string | null;
  entityType: string | null;
  entityStatus: string | null;
  state: string | null;
  postcode: string | null;
  website: string | null;
  linkedinSearchUrl: string;
};

// --- Free: ABR ABN Lookup (name search) -----------------------------------
async function lookupAbr(name: string): Promise<Partial<EntityEnrichment>> {
  const guid = process.env.ABR_LOOKUP_GUID;
  if (!guid) return {};

  // ABR "ABRSearchByNameSimpleProtocol" JSON endpoint.
  const endpoint = new URL("https://abr.business.gov.au/json/MatchingNames.aspx");
  endpoint.searchParams.set("name", name);
  endpoint.searchParams.set("maxResults", "1");
  endpoint.searchParams.set("guid", guid);

  try {
    const res = await fetch(endpoint.toString());
    if (!res.ok) return {};
    // ABR returns JSONP-style: callback({...}). Strip the wrapper.
    const text = await res.text();
    const json = JSON.parse(text.replace(/^[^(]*\(/, "").replace(/\);?\s*$/, ""));
    const top = json?.Names?.[0];
    if (!top) return {};
    return {
      abn: top.Abn ?? null,
      entityType: top.NameType ?? null,
      entityStatus: top.AbnStatus ?? null,
      state: top.State ?? null,
      postcode: top.Postcode ?? null,
    };
  } catch (err) {
    console.warn(`[enrich] ABR lookup failed for "${name}":`, (err as Error).message);
    return {};
  }
}

export async function enrichEntity(name: string): Promise<EntityEnrichment> {
  const abr = await lookupAbr(name);
  const linkedinSearchUrl =
    "https://www.linkedin.com/search/results/companies/?keywords=" +
    encodeURIComponent(name);

  return {
    abn: abr.abn ?? null,
    entityType: abr.entityType ?? null,
    entityStatus: abr.entityStatus ?? null,
    state: abr.state ?? null,
    postcode: abr.postcode ?? null,
    website: null, // populate from a domain-finder when you add one
    linkedinSearchUrl,
  };
}

// --- Paid slot: contact emails (NO-OP for v1) ------------------------------
// Returns contact rows to attach to the proponent. For now we synthesise a
// people-search link only. Swap the body for an Apollo/Hunter call keyed off
// the company domain to populate real emails.
export type ContactStub = {
  name: string | null;
  title: string | null;
  email: string | null;
  linkedinUrl: string | null;
  source: string;
};

export async function enrichContacts(proponentName: string): Promise<ContactStub[]> {
  // v1: one "find people here" pointer, no email. Honest about the gap.
  return [
    {
      name: null,
      title: "Decision-makers (search)",
      email: null,
      linkedinUrl:
        "https://www.linkedin.com/search/results/people/?keywords=" +
        encodeURIComponent(`${proponentName} development`),
      source: "linkedin-search-stub",
    },
  ];
}

export { makeMatchKey };
