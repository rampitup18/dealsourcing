/**
 * Cold email composer — drafts the outreach, in the voice of an originator
 * (your "Scott"). One draft per lead above the surface threshold.
 *
 * Deliberate design choice: this DRAFTS, it does not SEND. In a relatively small
 * market, the first contact is relationship capital — an originator's credible,
 * specific, human note. We generate the draft and store it as DRAFT status; a
 * human reviews and sends. Tone guidance below keeps it short, specific to the
 * actual project, and free of bot-tells.
 *
 * Australian context: B2B cold outreach is permitted under the Spam Act 2003
 * provided the sender is honestly identified and an unsubscribe path exists.
 * The signature block placeholder covers identification; add your unsubscribe
 * line before sending at any volume.
 */

import { prisma } from "../lib/db";
import { completeJson } from "../lib/anthropic";
import { MANDATE } from "../lib/mandate";

interface EmailOutput {
  subject: string;
  body: string;
}

const SYSTEM = `You write first-contact outreach for an originator at ${MANDATE.firmName}.

WHO WE ARE (for your understanding, do not paste verbatim):
${MANDATE.thesis}

VOICE & RULES:
- Write as a real person doing origination, not a marketing bot.
- Short: 90-130 words. A busy developer should read it in 20 seconds.
- Open with a specific, accurate reference to THEIR project — the real signal
  that we noticed them (their connection enquiry / referral), not flattery.
- One clear, low-friction ask: a short call to learn about the project and where
  they are on predevelopment funding. Not a pitch, a question.
- No hype, no buzzwords ("synergies", "leverage", "cutting-edge"), no em dashes.
- Plain sign-off with a [Name], [Title], ${MANDATE.firmName}, [email] placeholder.
- Do not invent facts about the project beyond what you're given.

Return ONLY JSON, no code fences:
{ "subject": "<concise, specific, lowercase-ish, no clickbait>", "body": "<the email>" }`;

export async function composeEmailsForLeads(): Promise<number> {
  const leads = await prisma.lead.findMany({
    where: {
      emailBody: null,
      fitScore: { gte: MANDATE.surfaceThreshold },
    },
    include: { project: { include: { proponent: true } } },
  });

  let drafted = 0;

  for (const lead of leads) {
    const p = lead.project;
    const user = `PROJECT: ${p.name}
TECHNOLOGY: ${p.technology}${p.capacityMw ? `, ${p.capacityMw} MW` : ""}
STAGE: ${p.stage}
LOCATION: ${p.region ?? p.state ?? "Australia"}
PROPONENT: ${p.proponent.rawNames[0] ?? p.proponent.name}
HOW WE FOUND THEM: ${p.stage === "ENQUIRY" ? "their grid connection enquiry" : "public project records"}
WHY THEY FIT (internal, do not quote): ${lead.rationale}`;

    let out: EmailOutput;
    try {
      out = await completeJson<EmailOutput>({ system: SYSTEM, user, maxTokens: 600 });
    } catch (err) {
      console.error(`[email] failed for lead ${lead.id}:`, String(err));
      continue;
    }

    await prisma.lead.update({
      where: { id: lead.id },
      data: { emailSubject: out.subject, emailBody: out.body, emailStatus: "DRAFT" },
    });
    drafted++;
    console.log(`[email] drafted for ${p.name}`);
  }

  return drafted;
}

/** Re-draft a single lead on demand (used by the dashboard "regenerate" button). */
export async function composeEmailForLead(leadId: string): Promise<EmailOutput | null> {
  const lead = await prisma.lead.findUnique({
    where: { id: leadId },
    include: { project: { include: { proponent: true } } },
  });
  if (!lead) return null;

  const p = lead.project;
  const out = await completeJson<EmailOutput>({
    system: SYSTEM,
    user: `PROJECT: ${p.name}
TECHNOLOGY: ${p.technology}${p.capacityMw ? `, ${p.capacityMw} MW` : ""}
STAGE: ${p.stage}
LOCATION: ${p.region ?? p.state ?? "Australia"}
PROPONENT: ${p.proponent.rawNames[0] ?? p.proponent.name}
WHY THEY FIT (internal): ${lead.rationale}`,
    maxTokens: 600,
  });

  await prisma.lead.update({
    where: { id: leadId },
    data: { emailSubject: out.subject, emailBody: out.body, emailStatus: "DRAFT" },
  });
  return out;
}
