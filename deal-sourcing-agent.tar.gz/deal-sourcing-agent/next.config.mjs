/** @type {import('next').NextConfig} */
const nextConfig = {
  // The ingestion modules import xlsx and the prisma client; keep them server-only.
  serverExternalPackages: ["xlsx", "@prisma/client"],
};

export default nextConfig;
