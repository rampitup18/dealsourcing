import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#10141A",
        slate: "#5B6573",
        mute: "#8A94A1",
        mist: "#E4E8EC",
        line: "#EEF1F4",
        paper: "#F6F7F9",
        panel: "#FFFFFF",
        // signal palette — fit tiers
        strong: "#127E58",
        watch: "#B45309",
        cold: "#8A94A1",
        accent: "#0E7C7B",
        "accent-ink": "#0A5A59",
      },
      fontFamily: {
        display: ["var(--font-display)", "ui-sans-serif", "system-ui"],
        sans: ["var(--font-sans)", "ui-sans-serif", "system-ui"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      fontWeight: {
        "400": "400",
        "500": "500",
        "600": "600",
        "700": "700",
      },
      boxShadow: {
        panel: "0 1px 2px rgba(16,20,26,0.04), 0 1px 1px rgba(16,20,26,0.03)",
      },
    },
  },
  plugins: [],
};
export default config;
