export function fitBand(score: number): "hi" | "mid" | "lo" {
  if (score >= 75) return "hi";
  if (score >= 55) return "mid";
  return "lo";
}

export const TECH_LABEL: Record<string, string> = {
  SOLAR: "Solar",
  WIND: "Wind",
  BATTERY: "Battery",
  SOLAR_BATTERY: "Solar+Battery",
  PUMPED_HYDRO: "Pumped Hydro",
  HYBRID: "Hybrid",
  GREEN_HYDROGEN: "Green H₂",
  TRANSMISSION: "Transmission",
  OTHER: "Other",
};

export const STAGE_LABEL: Record<string, string> = {
  ENQUIRY: "Connection Enquiry",
  PROPOSED: "Proposed",
  COMMITTED: "Committed",
  OPERATING: "Operating",
  WITHDRAWN: "Withdrawn",
  UNKNOWN: "Unknown",
};
