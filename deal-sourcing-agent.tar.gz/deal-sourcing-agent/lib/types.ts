// The single normalised shape that AEMO and EPBC records are mapped into
// before enrichment, qualification and persistence.

export type RawLead = {
  projectName: string;
  proponentName: string;
  technology: "SOLAR" | "WIND" | "BATTERY" | "HYBRID" | "PUMPED_HYDRO" | "OTHER";
  capacityMw: number | null;
  storageMwh: number | null;
  region: string | null;
  status: "ENQUIRY" | "PROPOSED" | "COMMITTED" | "OPERATING" | "WITHDRAWN" | "UNKNOWN";
  latitude: number | null;
  longitude: number | null;
  source: "AEMO" | "EPBC";
  aemoDuid?: string | null;
  epbcReference?: string | null;
  sourceUrl?: string | null;
};

// A natural key so the same project from two runs (or two sources) collapses
// to one row. Proponent + a normalised project name + region is robust enough
// for a screening tool; tighten with DUID/EPBC ref when present.
export function dedupeKeyFor(lead: Pick<RawLead, "proponentName" | "projectName" | "region" | "aemoDuid" | "epbcReference">): string {
  if (lead.aemoDuid) return `duid:${lead.aemoDuid.toLowerCase()}`;
  if (lead.epbcReference) return `epbc:${lead.epbcReference.toLowerCase()}`;
  const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  return `nk:${slug(lead.proponentName)}:${slug(lead.projectName)}:${(lead.region ?? "na").toLowerCase()}`;
}

export type QualificationResult = {
  fitScore: number;
  stageFit: number;
  scaleFit: number;
  techFit: number;
  proponentFit: number;
  recommendation: "PURSUE" | "WATCH" | "PASS";
  rationale: string;
  estimatedCapexAud: number | null;
};
