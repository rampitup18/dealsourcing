import Anthropic from "@anthropic-ai/sdk";

export const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

export const MODEL = process.env.ANTHROPIC_MODEL ?? "claude-sonnet-4-5";

/**
 * Ask the model for strict JSON and parse it safely. We instruct the model to
 * emit nothing but JSON, then strip any stray code fences before parsing.
 */
export async function completeJson<T>(args: {
  system: string;
  user: string;
  maxTokens?: number;
}): Promise<T> {
  const res = await anthropic.messages.create({
    model: MODEL,
    max_tokens: args.maxTokens ?? 1500,
    system: args.system,
    messages: [{ role: "user", content: args.user }],
  });

  const text = res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("\n")
    .replace(/```json|```/g, "")
    .trim();

  try {
    return JSON.parse(text) as T;
  } catch (err) {
    throw new Error(
      `Model did not return valid JSON. Raw output:\n${text}\n\n(${String(err)})`,
    );
  }
}

/** Plain text completion (used for the cold email body). */
export async function completeText(args: {
  system: string;
  user: string;
  maxTokens?: number;
}): Promise<string> {
  const res = await anthropic.messages.create({
    model: MODEL,
    max_tokens: args.maxTokens ?? 1000,
    system: args.system,
    messages: [{ role: "user", content: args.user }],
  });
  return res.content
    .filter((b): b is Anthropic.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("\n")
    .trim();
}
