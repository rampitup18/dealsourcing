/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    // Prisma client is server-only; keep it out of the client bundle.
    serverComponentsExternalPackages: ["@prisma/client", "@anthropic-ai/sdk"],
  },
};
module.exports = nextConfig;
