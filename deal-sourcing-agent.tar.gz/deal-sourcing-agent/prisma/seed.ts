// Seed realistic-shaped sample data so the dashboard runs end-to-end before
// you wire up the live AEMO/EPBC feeds. Project names and proponents here are
// illustrative composites for development only — not real deals.
//
//   npm run db:push && npm run seed && npm run dev

import { PrismaClient } from "@prisma/client";
import { makeMatchKey } from "../lib/mandate";

const prisma = new PrismaClient();

type Seed = {
  proponent: string;
  major?: boolean;
  abn?: string;
  entityType?: string;
  state?: string;
  postcode?: string;
  projects: Array<{
    name: string;
    tech: "SOLAR" | "WIND" | "BATTERY" | "HYBRID" | "PUMPED_HYDRO";
    mw?: number;
    mwh?: number;
    region: string;
    status: "ENQUIRY" | "PROPOSED" | "COMMITTED" | "OPERATING";
    lat?: number;
    lng?: number;
    source: "AEMO" | "EPBC" | "BOTH";
    epbc?: string;
    fit: number; stage: number; scale: number; techFit: number; prop: number;
    rec: "PURSUE" | "WATCH" | "PASS";
    rationale: string;
    capex?: number;
    email?: { subject: string; body: string };
  }>;
};

const DATA: Seed[] = [
  {
    proponent: "Mirning Renewables Pty Ltd",
    abn: "61 627 884 110",
    entityType: "Australian Private Company",
    state: "SA",
    postcode: "5000",
    projects: [
      {
        name: "Eyre Peninsula Solar + Storage",
        tech: "HYBRID", mw: 420, mwh: 800, region: "SA1", status: "PROPOSED",
        lat: -33.74, lng: 135.86, source: "BOTH", epbc: "2024/09812",
        fit: 91, stage: 88, scale: 90, techFit: 95, prop: 92, rec: "PURSUE",
        rationale: "Pre-FID hybrid at sweet-spot scale from an independent developer; classic predevelopment funding gap.",
        capex: 630_000_000,
        email: {
          subject: "Eyre Peninsula Solar + Storage — predevelopment capital",
          body:
`Hi,

I came across the Eyre Peninsula Solar and Storage project, your 420 MW solar-plus-battery development in South Australia, and wanted to reach out.

We are Blockmate Infrastructure. We provide pre-FID predevelopment and bridge capital, typically A$1 to 50M, to carry projects through interconnection, feasibility, permitting and long-lead equipment ahead of a final investment decision.

If you are looking at predevelopment funding to get this to FID, I would welcome a short call to hear where things are at. No agenda beyond understanding the project and whether we can be useful.

Would you be open to a brief conversation in the next week or two?

Scott
Infrastructure Partner, Blockmate Infrastructure
scott@blockmate.example`,
        },
      },
      {
        name: "Spencer Gulf Wind",
        tech: "WIND", mw: 300, region: "SA1", status: "ENQUIRY",
        lat: -32.49, lng: 137.76, source: "AEMO",
        fit: 79, stage: 82, scale: 78, techFit: 90, prop: 80, rec: "WATCH",
        rationale: "Early connection enquiry from the same independent developer; worth tracking as it firms up.",
        capex: 450_000_000,
      },
    ],
  },
  {
    proponent: "Lachlan Valley Energy Pty Ltd",
    abn: "24 642 119 884",
    entityType: "Australian Private Company",
    state: "NSW",
    postcode: "2800",
    projects: [
      {
        name: "Central-West Orana BESS",
        tech: "BATTERY", mw: 250, mwh: 1000, region: "NSW1", status: "COMMITTED",
        lat: -32.25, lng: 148.61, source: "AEMO",
        fit: 84, stage: 70, scale: 85, techFit: 95, prop: 88, rec: "PURSUE",
        rationale: "Committed but pre-FID standalone battery in a REZ; mid-tier sponsor likely needs bridge capital to financial close.",
        capex: 375_000_000,
        email: {
          subject: "Central-West Orana BESS — bridge to financial close",
          body:
`Hi,

I noticed the Central-West Orana battery project, your 250 MW / 1,000 MWh storage development in the New South Wales REZ, has moved to committed status.

We are Blockmate Infrastructure. We provide pre-FID predevelopment and bridge capital, typically A$1 to 50M, structured as convertible notes or senior secured bridges, to carry projects through the gap ahead of financial close.

If a bridge into FID would be useful here, I would value a short call to understand where the project sits and whether our capital fits.

Open to a quick conversation?

Scott
Infrastructure Partner, Blockmate Infrastructure
scott@blockmate.example`,
        },
      },
    ],
  },
  {
    proponent: "Darling Downs Solar Holdings Pty Ltd",
    abn: "39 655 201 447",
    entityType: "Australian Private Company",
    state: "QLD",
    postcode: "4350",
    projects: [
      {
        name: "Western Downs Solar Farm Stage 2",
        tech: "SOLAR", mw: 180, region: "QLD1", status: "PROPOSED",
        lat: -26.93, lng: 150.7, source: "EPBC", epbc: "2024/09640",
        fit: 76, stage: 80, scale: 70, techFit: 95, prop: 78, rec: "WATCH",
        rationale: "Proposed stage-2 solar from a single-asset developer; scale at lower end but fundable predev need.",
        capex: 270_000_000,
        email: {
          subject: "Western Downs Solar Stage 2 — predevelopment funding",
          body:
`Hi,

I saw the referral for Western Downs Solar Farm Stage 2, your 180 MW solar project in Queensland, and wanted to introduce us.

We are Blockmate Infrastructure. We provide pre-FID predevelopment and bridge capital, typically A$1 to 50M, to fund interconnection, feasibility, permitting and equipment deposits ahead of a final investment decision.

If you are arranging predevelopment capital for Stage 2, I would welcome a short call to hear where it is at.

Would that be of interest?

Scott
Infrastructure Partner, Blockmate Infrastructure
scott@blockmate.example`,
        },
      },
    ],
  },
  {
    proponent: "AGL Energy Limited",
    major: true,
    abn: "74 115 061 375",
    entityType: "Australian Public Company",
    state: "NSW",
    postcode: "2000",
    projects: [
      {
        name: "Liddell Battery Expansion",
        tech: "BATTERY", mw: 500, mwh: 2000, region: "NSW1", status: "COMMITTED",
        lat: -32.37, lng: 150.98, source: "AEMO",
        fit: 28, stage: 55, scale: 80, techFit: 95, prop: 8, rec: "PASS",
        rationale: "Tier-1 utility funds its own predevelopment; no predev capital gap for Blockmate to fill.",
        capex: 750_000_000,
      },
    ],
  },
  {
    proponent: "Riverina Clean Power Pty Ltd",
    abn: "52 660 773 219",
    entityType: "Australian Private Company",
    state: "NSW",
    postcode: "2650",
    projects: [
      {
        name: "Murrumbidgee Pumped Hydro",
        tech: "PUMPED_HYDRO", mw: 600, region: "NSW1", status: "PROPOSED",
        lat: -35.1, lng: 147.37, source: "EPBC", epbc: "2023/09455",
        fit: 72, stage: 85, scale: 88, techFit: 70, prop: 85, rec: "WATCH",
        rationale: "Large pre-FID pumped hydro from an independent; long predev runway suits bridge capital but tech is capital-heavy and slow.",
        capex: 900_000_000,
      },
      {
        name: "Hay Plains Solar",
        tech: "SOLAR", mw: 90, region: "NSW1", status: "OPERATING",
        lat: -34.52, lng: 144.84, source: "AEMO",
        fit: 18, stage: 5, scale: 55, techFit: 95, prop: 60, rec: "PASS",
        rationale: "Already operating — out of mandate; retained as proponent track-record context.",
        capex: 135_000_000,
      },
    ],
  },
];

async function main() {
  console.log("Resetting sample data…");
  await prisma.coldEmail.deleteMany();
  await prisma.contact.deleteMany();
  await prisma.director.deleteMany();
  await prisma.project.deleteMany();
  await prisma.proponent.deleteMany();

  for (const s of DATA) {
    const proponent = await prisma.proponent.create({
      data: {
        name: s.proponent,
        matchKey: makeMatchKey(s.proponent) || s.proponent.toLowerCase(),
        abn: s.abn ?? null,
        entityType: s.entityType ?? null,
        entityStatus: "Active",
        state: s.state ?? null,
        postcode: s.postcode ?? null,
        website: null,
        linkedinSearchUrl:
          "https://www.linkedin.com/search/results/companies/?keywords=" +
          encodeURIComponent(s.proponent),
        enrichedAt: new Date(),
        contacts: {
          create: [
            {
              name: null,
              title: "Decision-makers (search)",
              email: null,
              linkedinUrl:
                "https://www.linkedin.com/search/results/people/?keywords=" +
                encodeURIComponent(`${s.proponent} development`),
              source: "linkedin-search-stub",
            },
          ],
        },
      },
    });

    for (const p of s.projects) {
      const dedupeKey = `seed:${proponent.matchKey}:${p.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
      const project = await prisma.project.create({
        data: {
          name: p.name,
          proponentId: proponent.id,
          technology: p.tech,
          capacityMw: p.mw ?? null,
          storageMwh: p.mwh ?? null,
          region: p.region,
          status: p.status,
          latitude: p.lat ?? null,
          longitude: p.lng ?? null,
          source: p.source,
          epbcReference: p.epbc ?? null,
          sourceUrl: p.source === "EPBC"
            ? "https://epbcpublicportal.environment.gov.au/"
            : "https://www.aemo.com.au/energy-systems/electricity/national-electricity-market-nem/nem-forecasting-and-planning/forecasting-and-planning-data/generation-information",
          fitScore: p.fit,
          stageFit: p.stage,
          scaleFit: p.scale,
          techFit: p.techFit,
          proponentFit: p.prop,
          recommendation: p.rec,
          rationale: p.rationale,
          estimatedCapexAud: p.capex ? BigInt(p.capex) : null,
          qualifiedAt: new Date(),
          dedupeKey,
        },
      });

      if (p.email) {
        await prisma.coldEmail.create({
          data: {
            projectId: project.id,
            subject: p.email.subject,
            body: p.email.body,
            status: "DRAFT",
            model: "seed",
          },
        });
      }
    }
  }

  const projects = await prisma.project.count();
  const proponents = await prisma.proponent.count();
  console.log(`Seeded ${projects} projects across ${proponents} proponents.`);
  await prisma.$disconnect();
}

main().catch(async (e) => {
  console.error(e);
  await prisma.$disconnect();
  process.exit(1);
});
