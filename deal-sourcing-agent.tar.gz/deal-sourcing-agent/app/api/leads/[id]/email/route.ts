import { NextResponse } from "next/server";
import { composeEmailForLead } from "@/ingest/compose-email";

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  try {
    const out = await composeEmailForLead(id);
    if (!out) return NextResponse.json({ error: "lead not found" }, { status: 404 });
    return NextResponse.json(out);
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
