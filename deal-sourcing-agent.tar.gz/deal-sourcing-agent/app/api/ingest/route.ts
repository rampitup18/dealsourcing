import { NextRequest, NextResponse } from "next/server";

// On-demand ingestion trigger. Protect with INGEST_TOKEN in production, or
// just run `npm run ingest` from a scheduled job (cron / GitHub Actions /
// Vercel Cron) which is the recommended path.
export async function POST(req: NextRequest) {
  const token = req.headers.get("x-ingest-token");
  if (process.env.INGEST_TOKEN && token !== process.env.INGEST_TOKEN) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    // Lazy import so the heavy ingestion deps stay out of the request path
    // unless this route is actually hit.
    const { runIngestion } = await import("@/ingest/run");
    if (typeof runIngestion === "function") {
      await runIngestion();
      return NextResponse.json({ ok: true });
    }
    return NextResponse.json(
      { error: "Run `npm run ingest` instead; this trigger is optional." },
      { status: 501 }
    );
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
