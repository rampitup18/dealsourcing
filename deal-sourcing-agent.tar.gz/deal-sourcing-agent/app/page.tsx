import Link from "next/link";
import { prisma } from "@/lib/db";
import { MANDATE } from "@/lib/mandate";
import { fitBand, TECH_LABEL, STAGE_LABEL } from "@/lib/ui";

export const dynamic = "force-dynamic";

export default async function Home() {
  const leads = await prisma.lead.findMany({
    where: { fitScore: { gte: MANDATE.surfaceThreshold }, status: { not: "ARCHIVED" } },
    orderBy: { fitScore: "desc" },
    include: { project: { include: { proponent: true } } },
  });

  const allLeads = await prisma.lead.count();
  const avgFit =
    leads.length > 0
      ? Math.round(leads.reduce((s, l) => s + l.fitScore, 0) / leads.length)
      : 0;
  const enquiryStage = leads.filter((l) => l.project.stage === "ENQUIRY").length;
  const drafted = leads.filter((l) => l.emailBody).length;

  return (
    <>
      <div className="page-head">
        <h1>Qualified leads</h1>
        <p className="lede">
          Renewable &amp; infrastructure projects scored against the Blockmate mandate.
          Showing fit ≥ {MANDATE.surfaceThreshold} ({allLeads} total in pipeline).
        </p>
      </div>

      <div className="stats">
        <div className="stat">
          <div className="n">{leads.length}</div>
          <div className="l">Surfaced leads</div>
        </div>
        <div className="stat">
          <div className="n">{enquiryStage}</div>
          <div className="l">At enquiry stage</div>
        </div>
        <div className="stat">
          <div className="n">{avgFit}</div>
          <div className="l">Avg fit score</div>
        </div>
        <div className="stat">
          <div className="n">{drafted}</div>
          <div className="l">Emails drafted</div>
        </div>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Project / Developer</th>
              <th>Tech</th>
              <th>Capacity</th>
              <th>Region</th>
              <th>Stage</th>
              <th>Fit</th>
            </tr>
          </thead>
          <tbody>
            {leads.map((l) => {
              const band = fitBand(l.fitScore);
              return (
                <tr key={l.id}>
                  <td className="col-name">
                    <Link href={`/leads/${l.id}`} style={{ display: "block" }}>
                      <div className="pname">{l.project.name}</div>
                      <div className="pdev">
                        {l.project.proponent.rawNames[0] ?? l.project.proponent.name}
                      </div>
                    </Link>
                  </td>
                  <td>
                    <Link href={`/leads/${l.id}`}>
                      <span className="chip tech">
                        {TECH_LABEL[l.project.technology] ?? l.project.technology}
                      </span>
                    </Link>
                  </td>
                  <td className="num">
                    <Link href={`/leads/${l.id}`}>
                      {l.project.capacityMw ? `${l.project.capacityMw} MW` : "—"}
                    </Link>
                  </td>
                  <td className="num">
                    <Link href={`/leads/${l.id}`}>{l.project.region ?? l.project.state ?? "—"}</Link>
                  </td>
                  <td>
                    <Link href={`/leads/${l.id}`}>
                      <span className={`chip stage-${l.project.stage}`}>
                        {STAGE_LABEL[l.project.stage] ?? l.project.stage}
                      </span>
                    </Link>
                  </td>
                  <td>
                    <Link href={`/leads/${l.id}`}>
                      <span className={`fit fit-${band}`}>
                        <span className="score">{l.fitScore}</span>
                        <span className="bar">
                          <i style={{ width: `${l.fitScore}%` }} />
                        </span>
                      </span>
                    </Link>
                  </td>
                </tr>
              );
            })}
            {leads.length === 0 && (
              <tr>
                <td colSpan={6} style={{ padding: "40px", textAlign: "center" }}>
                  <span className="empty">
                    No leads yet. Run <code>npm run seed</code> for demo data, or{" "}
                    <code>npm run pipeline</code> against the live feeds.
                  </span>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </>
  );
}
