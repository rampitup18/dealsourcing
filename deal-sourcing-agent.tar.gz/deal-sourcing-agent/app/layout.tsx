import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Deal Terminal — Blockmate Infrastructure",
  description: "Renewable & infrastructure deal sourcing",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const today = new Date().toLocaleDateString("en-AU", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
  return (
    <html lang="en">
      <body>
        <header className="topbar">
          <div className="shell topbar-inner">
            <a href="/" className="brand">
              <span className="mark">
                BLOCKMATE<b>/</b>SOURCE
              </span>
              <span className="sub">Deal Terminal</span>
            </a>
            <span className="meta">AEMO + EPBC · {today}</span>
          </div>
        </header>
        <main className="shell">{children}</main>
      </body>
    </html>
  );
}
