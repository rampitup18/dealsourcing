"use client";

import { useState } from "react";

export default function EmailPanel({
  leadId,
  initialSubject,
  initialBody,
}: {
  leadId: string;
  initialSubject: string | null;
  initialBody: string | null;
}) {
  const [subject, setSubject] = useState(initialSubject ?? "");
  const [body, setBody] = useState(initialBody ?? "");
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  const hasEmail = body.trim().length > 0;

  async function regenerate() {
    setBusy(true);
    try {
      const res = await fetch(`/api/leads/${leadId}/email`, { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        setSubject(data.subject ?? "");
        setBody(data.body ?? "");
      }
    } finally {
      setBusy(false);
    }
  }

  function copy() {
    navigator.clipboard.writeText(`Subject: ${subject}\n\n${body}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  if (!hasEmail) {
    return (
      <div className="body">
        <p className="empty" style={{ marginBottom: 12 }}>
          No draft yet. This lead scored below the outreach threshold, or the email step
          hasn&apos;t run.
        </p>
        <button className="btn primary" onClick={regenerate} disabled={busy}>
          {busy ? "drafting…" : "draft email"}
        </button>
      </div>
    );
  }

  const mailto = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

  return (
    <div className="body">
      <div className="email">
        <div className="subj">
          <span>subject</span>
          {subject}
        </div>
        <div className="bdy">{body}</div>
      </div>
      <div className="email-actions">
        <button className="btn primary" onClick={copy}>
          {copied ? "copied ✓" : "copy"}
        </button>
        <a className="btn" href={mailto}>
          open in mail
        </a>
        <button className="btn" onClick={regenerate} disabled={busy}>
          {busy ? "…" : "regenerate"}
        </button>
      </div>
    </div>
  );
}
